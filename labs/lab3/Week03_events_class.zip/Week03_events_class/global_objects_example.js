console.log(console)

console.log(__filename)
console.log(__dirname)

// setInterval(() => {
//     console.log("hi")
// }, 1000);

setTimeout(() => {
    console.log("Called after 2 sec")
}, 2000)
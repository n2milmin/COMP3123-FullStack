import React from 'react';
import Form from './Form';

export default class Display extends React.Component {

    constructor(props) {
        super(props)
    }

    render () {
        return (
            <div>
                <Form/>
                
            </div>
        )
    }
}
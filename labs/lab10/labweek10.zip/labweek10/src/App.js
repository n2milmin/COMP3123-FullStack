import logo from './logo.svg';
import './App.css';
import Display from './components/Display';

function App() {
  return (
    <div class='App'>
      <h1>Data Entry Form</h1>
      <Display/>
    </div>
  );
}

export default App;
